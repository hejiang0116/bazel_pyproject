# Project A
An XLA-optimized Python package.

## Installation
```bash
pip install my-unique-xla-project-a